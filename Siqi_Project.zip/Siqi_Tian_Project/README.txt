1.Code:
(1)Train.ipynb: Data pre-processing and model training
(2)Predict.ipynb: Using the CNN model to do the prediction on the testing data
2.'test_predictions.txt': Prediction results
3.model4_96.h5: Final CNN model
